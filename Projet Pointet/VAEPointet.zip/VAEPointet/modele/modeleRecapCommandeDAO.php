<?php    
require_once("connexion.php");	
    
    class RecapCommandeDAO{
        // retourne un tableau associatif à 2 dimensions (ligne / colonne) contenant tous les objets		
        public static function getInfoCommande() {
            $resultat = array();
            
            $req = " ";

            try {
                $curseur = Connexion::getInstance()->query($req);
                
                //plusieurs lignes de résultat
                while ($ligne = $curseur->fetch(PDO::FETCH_ASSOC)) {
                    $resultat[] = $ligne;
                }            
                return $resultat;
            }
            catch(PDOException $e) {
                print "Erreur !: " . $e->getMessage();
                die();
            }
        }
    }
?>

