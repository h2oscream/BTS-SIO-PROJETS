<?php    
require_once("connexion.php");	
    
    class AdminDAO{
        //fonction qui permet de valider le login et le mot de passe 
        public static function valider($login, $motDePasse) {
            $res = false;
             //requéte SQL
            $req = Connexion::getInstance()->prepare("SELECT * FROM utilisateurs WHERE login=:login");
            try {
                $req->bindValue(':login', $login, PDO::PARAM_STR);
                $req->execute();
                
                if($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
                    $res = password_verify($motDePasse, $ligne['motDePasse']);
                }     
            }
            catch(PDOException $e) {
                print "Erreur !: " . $e->getMessage();
                die();
            }    
            return $res;
        }
        
        /** function inscrire pour ajouter un administrateur ou un utilisateur dans la base de données.
        *mettre les 6 champs de la table utilisateurs pour l'inscription. page unique avec url pour incrire admin
        *retourne un tableau associatif à 2 dimensions (ligne / colonne) contenant tous les objets		
        *public static function inscrire($nom, $login, $motDePasse) {
        *     //requéte SQL
        *    $req = Connexion::getInstance()->prepare("INSERT into `utilisateurs` (nom, login, motDePasse) VALUES(:nom, :login, :motDePasse)");
        *    try {
        *        $req->bindValue(':nom', $nom, PDO::PARAM_STR);
        *        $req->bindValue(':login', $login, PDO::PARAM_STR);
        *        // mot de passe crypté
        *        $req->bindValue(':motDePasse', password_hash($motDePasse, PASSWORD_DEFAULT), PDO::PARAM_STR);                
        *        $req->execute();
        *    }
        *    catch(PDOException $e) {
        *        print "Erreur !: " . $e->getMessage();
        *        die();
        *    }            
        *}
        */
    }
?>