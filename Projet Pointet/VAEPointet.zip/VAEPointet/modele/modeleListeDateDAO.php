<?php    
require_once("connexion.php");	
    
    class ListeDateDAO{
        // retourne un tableau associatif à 2 dimensions (ligne / colonne) contenant tous les objets		
        public static function readAll() {
            $resultat = array();
            
            $req = "SELECT DISTINCT dateCalendrier FROM plat";

            try {
                $curseur = Connexion::getInstance()->query($req);
                
                //plusieurs lignes de résultat
                while ($ligne = $curseur->fetch(PDO::FETCH_ASSOC)) {
                    $resultat[] = $ligne;
                }            
                return $resultat;
            }
            catch(PDOException $e) {
                print "Erreur !: " . $e->getMessage();
                die();
            }
        }

        //fonction qui permet de recuperer un plat selon sa date
        public static function getPrix($datep, $idp) {
            $resultat = array();
            
            try {
                $req = Connexion::getInstance()->prepare("SELECT prix FROM plat WHERE dateCalendrier = :datep AND id = :idp");
                $req->bindValue(':datep',$datep, PDO::PARAM_STR);
                $req->bindValue(':idp',$idp, PDO::PARAM_INT);
				$req->execute();
                
                //Plusieurs lignes de résultat
                while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
                    $resultat[] = $ligne;
                }
                
                
                return $resultat;

            }
            catch(PDOException $e) {
                print "Erreur !: " . $e->getMessage();
                die();
            }
        } 

         //fonction qui permet de recuperer le prix
         public static function getPlatsByDate($datep) {
            $resultat = array();
            
            try {
                $req = Connexion::getInstance()->prepare("SELECT *  FROM plat WHERE dateCalendrier = :datep");
                $req->bindValue(':datep',$datep, PDO::PARAM_STR);
				$req->execute();
                
                //Plusieurs lignes de résultat
                while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
                    $resultat[] = $ligne;
                }
                
                
                return $resultat;

            }
            catch(PDOException $e) {
                print "Erreur !: " . $e->getMessage();
                die();
            }
        } 

        public static function addCommande($d,$h,$r,$c,$com,$t,$idu) {
            

            $sql="INSERT INTO Commande (dateC,heure,recap,contenant,commentaire,total,idUtilisateurs)

                VALUES(:dateC,:heure,:recap,:cont,:com,:tot,:idutil)";

            try {
                $req = Connexion::getInstance()->prepare($sql);

                $req->bindValue(':dateC',$d, PDO::PARAM_STR);
                $req->bindValue(':heure',$h, PDO::PARAM_STR);
                $req->bindValue(':recap',$r, PDO::PARAM_INT);
                $req->bindValue(':cont',$c, PDO::PARAM_INT);
                $req->bindValue(':com',$com, PDO::PARAM_STR);
                $req->bindValue(':tot',$t, PDO::PARAM_STR);
                $req->bindValue(':idutil',$idu, PDO::PARAM_INT);
                $nbLigne =  $req->execute();

                return $nbLigne;

            }
            catch(PDOException $e) {
                print "Erreur !: " . $e->getMessage();
                die();
            }
        }
        /**public static function ajouterPlatCommande() {
            $resultat = array();
            
            try {
                $req = Connexion::getInstance()->prepare("SELECT *  FROM plat WHERE dateCalendrier = :datep");
                $req->bindValue(':datep',$datep, PDO::PARAM_STR);
				$req->execute();
                
                //Plusieurs lignes de résultat
                while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
                    $resultat[] = $ligne;
                }
                
                
                return $resultat;

            }
            catch(PDOException $e) {
                print "Erreur !: " . $e->getMessage();
                die();
            }
        } 
        */
        
        
       
    }
?>