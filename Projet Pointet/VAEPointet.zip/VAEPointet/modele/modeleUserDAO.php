<?php    
require_once("connexion.php");	
    
class UserDAO{
    // retourne un tableau associatif à 2 dimensions (ligne / colonne) contenant tous les objets
    public static function verifie($nom, $prenom) {
        $res = -1;
        //requéte SQL
        $req = Connexion::getInstance()->prepare("SELECT * FROM utilisateurs WHERE nom=:nom");
        try {
            $req->bindValue(':nom', $nom, PDO::PARAM_STR);
            $req->execute();
            
            if($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
                $res = true;
            }     
        }
        catch(PDOException $e) {
            print "Erreur !: " . $e->getMessage();
            die();
        }    
        return $ligne['id'];
    }	
}
