	<!-- Lien vers le css-->
<link rel="stylesheet" type="text/css" href="css/cssAccueil.css"/>

<center>
		<!-- boutons vers commande et connexion-->
		
	<a href="//localhost/VAEPointet/?action=connexionUtilisateur">
		<button type="submit">Connexion</button>
	</a>


	<a href="//localhost/VAEPointet/?action=connexionAdministrateur">
	<button name = "btnAdmin" type="submit">admin</button>
	</a>


	<div contenteditable="true">
	<h1>Bienvenue sur le site de ventes a emporter du Lycée Charles Pointet</h1>
	</div>
	<br><br>
	<h2>Liste des jours de vente :</h2>
	<br>

	<?php
		for ($i = 0; $i < count($listeDate); $i++) {

			$datep = $listeDate[$i]['dateCalendrier'];

			//redirection

			echo "<a href='./?action=commande&datep=" . $datep . "'>" . $datep . "</a>";

			echo  '<br /> ';
			?>
			<br>

		<?php
		}
		?>
	
</center>


