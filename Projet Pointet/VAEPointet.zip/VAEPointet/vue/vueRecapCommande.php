  <!--TITRE-->
<h1>Voici votre commande: </h1>

<br>

  <!-- Lien vers le css-->
<link rel="stylesheet" type="text/css" href="css/cssRecapCommande.css"/> 

  <!-- Description de votre commande-->
<form action="./?action=insererCommande ?>" method="POST">
  <p> 

  Votre nom : <?php echo $_SESSION['nom']; ?> 
  <br><br>
  Votre prenom : <?php echo $_SESSION['prenom']; ?> 
  <br><br>
  Heure de votre commande : <?php echo $h ?> 
  
  <br><br>
  recap par mail : <?php echo $r ?> 
  <br><br>
  J'apporte mes contenants: <?php echo $c ?> 

  <br><br>
  Votre commentaire :  <br><?php echo $com ?> 
  <br><br>
  Date du jour :  <?php echo $d ?> 

  </p>



  <br>
  <br>
  <center>
    <!-- bouton vers le récap de la commande après avoir commander-->
    <a href="//localhost/VAEPointet/">
    <input type="submit" name="submit" value="Valider la Commande" >
    </a>
  </center>

</form> 
      
