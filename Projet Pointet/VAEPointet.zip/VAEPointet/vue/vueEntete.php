<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
            <!--Création d'une variable titre qui permet d'attribuer un titre au page-->
        <title><?php echo $titre ?></title>
    </head>
    <body>