    <!--importation du css-->
<link rel="stylesheet" type="text/css" href="css/cssConnexionAdministrateur.css"/>

<div id="container">
        <!--Affichage du formulaire et attribution des nom aux input-->
    <form action="./?action=authentifier" method="POST">
        
        <br>
        <label><b>Login :</b></label>
        <input type="text" placeholder="Entrer le Login" name="login" required>

        <br>
        <label><b>Mot de Passe : </b></label>
        <input type="password" placeholder="Entrer le Mot de Passe" name="motDePasse" required>

        <br><br>
        <input type="submit" id='submit' value='Se connecter' >

    </form>
</div>     
