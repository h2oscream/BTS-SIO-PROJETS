    <!--Affichage du formulaire et attribution des nom aux input-->
    <link rel="stylesheet" type="text/css" href="css/cssConnexionUtilisateur.css"/>
<div id="container">
    <form action="./?action=authentifierUtilisateur" method="POST">

        <br>
        <label><b>Nom :</b></label>
        <input type="text" placeholder="Entrer votre nom" name="nom" required>

        <br>
        <label><b>Prenom : </b></label>
        <input type="text" placeholder="Entrer votre prenom" name="prenom" required>

        <br><br>
        <input type="submit" id='submit' value='Se connecter' >

    </form> 
</div>

