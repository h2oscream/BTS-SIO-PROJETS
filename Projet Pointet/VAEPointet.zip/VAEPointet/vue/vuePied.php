      <!--Création du texte de bas de page-->
    <p id ="texteAdroite">
        Site de vente à emporter du Lycée Des Métiers Charles Pointet
    </p>

  </body>
</html>
<style type="text/css">
      #texteAdroite {
        margin:0;
        padding:0;
        position:absolute;
        bottom:0px;
        text-align: center;
      }
      body {
        background-image: url('images/01.jpg');
        margin: 0;
        background-repeat:no-repeat;
        background-attachment:fixed;
        background-size: cover;
        
       
	    }
    </style>