  <!-- Lien vers le css-->
<link rel="stylesheet" type="text/css" href="css/cssCommande.css"/>

<center>
  <!--Texte éditable par l'administrarteur-->
  <div contenteditable="true">
  Message du jour.
  </div>

  <br>
    <!--Affichage de la date choisie dans l'Accueil-->
  <h1>Liste des plats du <?php echo $datep;?></h1>


  <form action="./?action=recapCommande" method='POST'>


    <?php
      //Affichage des informations concernant les plats récupères dans le modeleListeDateDAO.
    for ($i = 0; $i < count($uneDate); $i++) {
    ?>

      <p id="principal">

        <br>    
        <?= "nom : ". $uneDate[$i]['nom']; ?> | 
        <?= "nombreCuisine : ". $uneDate[$i]['nombreCuisine']; ?> |
        <?= "nombreRestant : ". $uneDate[$i]['nombreRestant']; ?> | 
        <?= " prix: ". $uneDate[$i]['prix']."€"; ?> | 
        <?= "description : ". $uneDate[$i]['description']; ?>       


        <br><br>



        <label>Nombre de plats souhaités:</label>
        <?php
        $name = "P"."/".$uneDate[$i]['dateCalendrier']."/".$uneDate[$i]['id'];
        
          //Récuperation du nombre de plat souhaiter et attribution de sa date et de son id au plat.
        echo "<input  min='0' type='number' name='".$name."'>";
        
       

      ?>
      </p>

      

    <?php
    }
    ?>

    <br>

      <!--Time picker-->
      <br>
    <label for="appt">Heure de récuperation de la commande:</label>
    <br>
    <input type="time" id="heure" name="heure"
    min="08:00" max="18:00" required>
    <br>

    <br>
      <!-- les cases a cocher-->
    <input  type='checkbox' name='contenant' value='1'>
    Je souhaite prendre mes propres contenants.
    
    <br>
    <br>

    <input  type='checkbox' name='recap' value='1'>
    Je souhaite recevoir le récapitulatif de ma commande par mail.

    <br>
    <br>
      <!-- Message utilisateur-->
    <fieldset><legend>Commentaire :</legend>

      Entrez votre message :
      <textarea name="commentaire" value="" cols="40" rows=7></textarea>

    </fieldset>
    
    <br>

      <!-- bouton vers le récap de la commande après avoir commander-->
    <a href="//localhost/VAEPointet/?action=recapCommande">
    <input type="submit" name="submit" value="Commander" >
    </a>
  </form> 

    <br>

  <!-- bouton de retour a l'accueil-->
  <a href="//localhost/VAEPointet/?action=defaut">
    <button type="submit">retour</button>
    </a>
    <br>
</center>
  