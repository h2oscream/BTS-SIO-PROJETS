<?php
    //Vérifier si login OK
    include "$racine/modele/modeleUserDAO.php";
    include "$racine/modele/modeleListeDateDAO.php";
    $id = UserDAO::verifie($_POST['nom'], $_POST['prenom']);

    // appel des fonctions permettant de recuperer les données utiles à l'affichage 
    $listeDate = listeDateDAO::readAll();

    if($id>0){
        
        // on démarre une session
        session_start ();
        // on enregistre les paramètres de notre utilisateur comme variables de session
        $_SESSION['nom'] = $_POST['nom'];
        $_SESSION['prenom'] = $_POST['prenom'];
        $_SESSION['id'] = $id;
        
        // Affichage des vues
        $titre = "Accueil";
        include "$racine/vue/vueEntete.php";
        include "$racine/vue/vueAccueil.php";
        include "$racine/vue/vuePied.php";  
    }
    else{
        // Affichage des vues
        $titre = "Page de connexion de l'utilisateur";
        include "$racine/vue/vueEntete.php";
        include "$racine/vue/vueConnexionUtilisateur.php";
        include "$racine/vue/vuePied.php";   
    }
?>