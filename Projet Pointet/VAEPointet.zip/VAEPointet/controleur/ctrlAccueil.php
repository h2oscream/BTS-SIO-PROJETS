<?php
    //Détermination de la racine
    if ( $_SERVER["SCRIPT_FILENAME"] == __FILE__ )
    {
       $racine="..";
    }
	
	
    //include_once "$racine/modele/bd.objet.inc.php";
    include_once "$racine/modele/modeleListeDateDAO.php";


    // appel des fonctions permettant de recuperer les données utiles à l'affichage 
    $listeDate = listeDateDAO::readAll();
    
	
	// Affichage des vues
    $titre = "Accueil";
    include "$racine/vue/vueEntete.php";
    include "$racine/vue/vueAccueil.php";
    include "$racine/vue/vuePied.php";
?>