<?php
    //Détermination de la racine
    if ( $_SERVER["SCRIPT_FILENAME"] == __FILE__ ){
        $racine="..";
    }

    //appel du modeleUserDAO.php";
    include_once "$racine/modele/modeleUserDAO.php";


    // Affichage des vues
    $titre = "Page de connexion de l'utilisateur";
    include "$racine/vue/vueEntete.php";
    include "$racine/vue/vueConnexionUtilisateur.php";
    include "$racine/vue/vuePied.php";

?>