<?php
    session_start();
    //Détermination de la racine
    if ( $_SERVER["SCRIPT_FILENAME"] == __FILE__ )
    {
        $racine="..";
    }

    // on inclut les modèles nécessaires
    include_once "$racine/modele/connexion.php";
    include_once "$racine/modele/modeleRecapCommandeDAO.php";
    include_once "$racine/modele/modeleListeDateDAO.php";


    //récuperer nom prenom des variables de session
    $nom = $_SESSION['nom'];
    $prenom = $_SESSION['prenom'];
    $id = $_SESSION['id'];


    //calculer dateSysteme 
    $d = date('Y-m-d');

    //recuperer toutes les valeures post
    $h = $_POST['heure'];
    
    $r = 0;
    if(isset($_POST['recap'])){
        $r = $_POST['recap'] ;
    }
    
    $c = 0;
    if(isset($_POST['contenant'])){
        $c = $_POST['contenant'];
    }
    $com = $_POST['commentaire'];

    //calcul du total
    $info = array();
    $array = array_keys($_POST);
    $total = 0;
    
    foreach ($array as $value)
    {
        if(substr($value, 0, 1) == 'P'){
            $info = explode('/', $value);
            $prixPlat = ListeDateDAO::getPrix($info[1], $info[2]);
            $prix = $prixPlat[0]['prix'];
            $total = $total + $prix * intval($_POST[$value]);
        }
    }
        
        

    //formater les données avant de les passer a la méthode add
    $nbLignes = ListeDateDAO::addCommande($d,$h,$r,$c,$com,$total,$id);


     // Affichage des vues
     $titre = "Page de Récapitulatif";
     include "$racine/vue/vueEntete.php";
     include "$racine/vue/vueRecapCommande.php";
     include "$racine/vue/vuePied.php";
?>