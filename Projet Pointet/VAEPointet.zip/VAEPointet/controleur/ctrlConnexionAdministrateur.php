<?php
    //Détermination de la racine
    if ( $_SERVER["SCRIPT_FILENAME"] == __FILE__ ){
        $racine="..";
    }


    // Affichage des vues
    $titre = "Page de connexion de l'administrateur";
    include "$racine/vue/vueEntete.php";
    include "$racine/vue/vueConnexionAdministrateur.php";
    include "$racine/vue/vuePied.php";

?>