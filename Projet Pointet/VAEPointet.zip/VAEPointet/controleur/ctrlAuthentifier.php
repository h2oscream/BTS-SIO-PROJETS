<?php
    //Vérifier si login OK
    include "$racine/modele/modeleAdminDAO.php";
    include "$racine/modele/modeleListeDateDAO.php";
    $valide = AdminDAO::valider($_POST['login'], $_POST['motDePasse']);
    
    // appel des fonctions permettant de recuperer les données utiles à l'affichage 
    $listeDate = listeDateDAO::readAll();

    if($valide){
        
        // on démarre une session
        session_start ();
        // on enregistre les paramètres de notre administrateur comme variables de session
        $_SESSION['login'] = $_POST['login'];
        $_SESSION['motDePasse'] = $_POST['motDePasse'];
        
        // Affichage des vues
        $titre = "Accueil";
        include "$racine/vue/vueEntete.php";
        include "$racine/vue/vueAccueil.php";
        include "$racine/vue/vuePied.php";
    }
    else{
        // Affichage des vues
        $titre = "Page de connexion de l'administrateur";
        include "$racine/vue/vueEntete.php";
        include "$racine/vue/vueConnexionAdministrateur.php";
        include "$racine/vue/vuePied.php";    
    }

?>