<?php
    //Détermination de la racine
    if ( $_SERVER["SCRIPT_FILENAME"] == __FILE__ )
    {
        $racine="..";
    }

    // on inclut les modèles nécessaires
    include_once "$racine/modele/modeleListeDateDAO.php";

    

    // recupèration des donnees GET, POST, et SESSION
    $datep = $_GET["datep"];
    

    // appel des fonctions du modèle permettant de recuperer les données utiles à l'affichage 
    $uneDate = ListeDateDAO::getPlatsByDate($datep);
    

    // Affichage des vues
    $titre = "Page de Commande";
    include "$racine/vue/vueEntete.php";
    include "$racine/vue/vueCommande.php";
    include "$racine/vue/vuePied.php";
?>