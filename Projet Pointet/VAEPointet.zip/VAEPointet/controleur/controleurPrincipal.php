<?php
    //Fonction qui retourne le fichier controleur à utiliser
    function controleurPrincipal($action){
    
        //Chaque action va déterminer le controleur à appeler
        $lesActions = array();
        $lesActions["defaut"] = "ctrlAccueil.php";  
        $lesActions["commande"] = "ctrlCommande.php";
        $lesActions["recapCommande"] = "ctrlRecapCommande.php"; 
        $lesActions["connexionUtilisateur"] = "ctrlConnexionUtilisateur.php"; 
        $lesActions["connexionAdministrateur"] = "ctrlConnexionAdministrateur.php";
        $lesActions["authentifier"] = "ctrlAuthentifier.php"; 
        $lesActions["authentifierUtilisateur"] = "ctrlAuthentifierUtilisateur.php";

        $controleur = $lesActions["defaut"];
        
        //Permet de vérifier que l'action existe et renvoie le nom du contrôleur PHP    
        if (array_key_exists ( $action , $lesActions )){
            $controleur = $lesActions[$action];
        }
        
        return $controleur;
    }

?> 