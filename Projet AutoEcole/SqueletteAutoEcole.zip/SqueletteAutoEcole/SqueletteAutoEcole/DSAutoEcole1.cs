﻿namespace SqueletteAutoEcole
{


    partial class DSAutoEcole
    {
    }
}
